package com.example.appdisabler;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.content.pm.ApplicationInfo;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuRemoteProcess;

public class MainActivity extends Activity {
    private static final int REQ = 42;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private Spinner userSpinner;
    private LinearLayout list;
    private TextView status;
    private Button refresh;
    private Button disable;
    private final List<Integer> userIds = new ArrayList<>();
    private final List<String> packages = new ArrayList<>();
    private final Set<String> selected = new LinkedHashSet<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 20, 20, 12);

        TextView title = new TextView(this);
        title.setText("App Disabler — Shizuku");
        title.setTextSize(21);
        title.setTextColor(Color.BLACK);
        title.setPadding(0,0,0,12);
        root.addView(title);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        userSpinner = new Spinner(this);
        bar.addView(userSpinner, new LinearLayout.LayoutParams(0, -2, 1));

        refresh = new Button(this);
        refresh.setText("Refresh");
        bar.addView(refresh, new LinearLayout.LayoutParams(-2, -2));

        root.addView(bar);

        status = new TextView(this);
        status.setText("Starting…");
        status.setPadding(0, 8, 0, 8);
        root.addView(status);

        LinearLayout actions = new LinearLayout(this);

        Button selectAll = new Button(this);
        selectAll.setText("Select all");
        actions.addView(selectAll, new LinearLayout.LayoutParams(0, -2, 1));

        Button clear = new Button(this);
        clear.setText("Clear");
        actions.addView(clear, new LinearLayout.LayoutParams(0, -2, 1));

        disable = new Button(this);
        disable.setText("Disable selected");
        actions.addView(disable, new LinearLayout.LayoutParams(0, -2, 1));

        root.addView(actions);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);

        refresh.setOnClickListener(v -> loadUsers());
        userSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < userIds.size()) loadPackages(userIds.get(pos));
            }
        });
        selectAll.setOnClickListener(v -> setAll(true));
        clear.setOnClickListener(v -> setAll(false));
        disable.setOnClickListener(v -> disableSelected());

        if (!Shizuku.pingBinder()) {
            status.setText("Shizuku is not running. Start Shizuku, then tap Refresh.");
            return;
        }

        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Shizuku.addRequestPermissionResultListener((requestCode, grantResult) -> {
                if (requestCode == REQ) loadUsers();
            });
            Shizuku.requestPermission(REQ);
        } else {
            loadUsers();
        }
    }

    private void loadUsers() {
        status.setText("Reading Android users…");
        executor.execute(() -> {
            CommandResult r = run("cmd", "user", "list");
            List<Integer> ids = new ArrayList<>();
            List<String> labels = new ArrayList<>();

            if (r.exit != 0 || r.out.trim().isEmpty()) {
                ids.add(0);
                labels.add("User 0 (Owner) — user list unavailable");
            } else {
                for (String line : r.out.split("\\n")) {
                    java.util.regex.Matcher m =
                        java.util.regex.Pattern.compile("UserInfo\\{(\\d+):([^:}]+)").matcher(line);
                    if (m.find()) {
                        int id = Integer.parseInt(m.group(1));
                        String name = m.group(2).trim();
                        ids.add(id);
                        labels.add("User " + id + " — " + name);
                    }
                }
                if (ids.isEmpty()) {
                    ids.add(0);
                    labels.add("User 0 (Owner)");
                }
            }

            final ArrayList<Integer> fIds = new ArrayList<>(ids);
            final ArrayList<String> fLabels = new ArrayList<>(labels);
            main.post(() -> {
                userIds.clear();
                userIds.addAll(fIds);
                ArrayAdapter<String> a = new ArrayAdapter<String>(
                    this, android.R.layout.simple_spinner_item, fLabels);
                a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                userSpinner.setAdapter(a);
                status.setText("Found " + fIds.size() + " Android user/profile entries.");
                if (!fIds.isEmpty()) loadPackages(fIds.get(0));
            });
        });
    }

    private void loadPackages(int userId) {
        status.setText("Reading packages for user " + userId + "…");
        list.removeAllViews();
        packages.clear();
        selected.clear();

        executor.execute(() -> {
            CommandResult r = run("pm", "list", "packages", "--user", String.valueOf(userId));
            ArrayList<String> pkgs = new ArrayList<>();
            for (String line : r.out.split("\\n")) {
                line = line.trim();
                if (line.startsWith("package:")) {
                    String p = line.substring(8).trim();
                    if (!p.isEmpty()) pkgs.add(p);
                }
            }
            Collections.sort(pkgs);
            main.post(() -> {
                if (r.exit != 0) {
                    status.setText("User " + userId + " is inaccessible: " + clean(r.err));
                    Toast.makeText(this, "Permission denied/inaccessible for user " + userId,
                            Toast.LENGTH_LONG).show();
                    return;
                }
                packages.addAll(pkgs);
                renderPackages(userId);
                status.setText("User " + userId + ": " + pkgs.size() + " packages.");
            });
        });
    }

    private void renderPackages(int userId) {
        list.removeAllViews();
        for (String pkg : packages) {
            CheckBox cb = new CheckBox(this);
            cb.setText(pkg);
            cb.setTextSize(14);
            cb.setTag(pkg);
            cb.setOnCheckedChangeListener((button, checked) -> {
                if (checked) selected.add(pkg); else selected.remove(pkg);
            });
            list.addView(cb);
        }
    }

    private void setAll(boolean value) {
        selected.clear();
        for (int i = 0; i < list.getChildCount(); i++) {
            View v = list.getChildAt(i);
            if (v instanceof CheckBox) {
                CheckBox cb = (CheckBox)v;
                cb.setOnCheckedChangeListener(null);
                cb.setChecked(value);
                String p = String.valueOf(cb.getTag());
                if (value) selected.add(p);
                cb.setOnCheckedChangeListener((button, checked) -> {
                    if (checked) selected.add(p); else selected.remove(p);
                });
            }
        }
        status.setText(value ? ("Selected " + selected.size() + " packages.")
                             : "Selection cleared.");
    }

    private void disableSelected() {
        if (selected.isEmpty()) {
            Toast.makeText(this, "Select at least one package.", Toast.LENGTH_SHORT).show();
            return;
        }
        final int userId = userIds.get(userSpinner.getSelectedItemPosition());
        final ArrayList<String> work = new ArrayList<>(selected);

        disable.setEnabled(false);
        status.setText("Disabling " + work.size() + " packages for user " + userId + "…");

        executor.execute(() -> {
            int ok = 0, fail = 0;
            StringBuilder errors = new StringBuilder();

            for (String pkg : work) {
                // Do not let the app disable itself or Shizuku.
                if (pkg.equals(getPackageName()) || pkg.equals("moe.shizuku.privileged.api")) {
                    fail++;
                    errors.append(pkg).append(": protected\n");
                    continue;
                }
                CommandResult r = run("pm", "disable-user", "--user",
                        String.valueOf(userId), pkg);
                if (r.exit == 0) ok++;
                else {
                    fail++;
                    errors.append(pkg).append(": ")
                          .append(clean(r.err.isEmpty() ? r.out : r.err)).append("\n");
                }
            }

            final int fOk = ok, fFail = fail;
            main.post(() -> {
                disable.setEnabled(true);
                selected.clear();
                status.setText("Finished. Disabled: " + fOk + " | Failed/protected: " + fFail);
                loadPackages(userId);
            });
        });
    }

    private CommandResult run(String... command) {
        ShizukuRemoteProcess p = null;
        try {
            p = Shizuku.newProcess(command, null, null);
            String out = read(p.getInputStream());
            String err = read(p.getErrorStream());
            int exit = p.waitFor();
            return new CommandResult(exit, out, err);
        } catch (Throwable t) {
            return new CommandResult(-1, "", t.toString());
        } finally {
            if (p != null) {
                try { p.destroy(); } catch (Throwable ignored) {}
            }
        }
    }

    private String read(InputStream in) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        StringBuilder s = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) s.append(line).append('\n');
        return s.toString();
    }

    private String clean(String s) {
        s = s == null ? "" : s.trim().replace('\n', ' ');
        return s.length() > 180 ? s.substring(0, 180) : s;
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private static class CommandResult {
        final int exit; final String out; final String err;
        CommandResult(int e, String o, String r) { exit=e; out=o; err=r; }
    }
}
